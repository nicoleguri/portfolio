import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re
from datetime import datetime
from recipe_bot import RecipeSearchBot  
from check_db import RecipeDatabase  
import random
from textblob import TextBlob

# Initialise the database
db = RecipeDatabase('recipes.db')

# Global dictionary for context tracking
context = {
    "last_recipe_title": None,
    "last_recipe_ingredients": None,
    "last_recipe_directions": None,
    "last_intent": None,
}

# Load datasets for small talk and general Q&A
qa_data = pd.read_csv('COMP3074-CW1-Dataset.csv')
questions = qa_data['Question'].tolist()
answers = qa_data['Answer'].tolist()

small_talk_data = pd.read_csv('small_talk_dataset.csv')
small_talk_questions = small_talk_data['Question'].tolist()
small_talk_responses = small_talk_data['Response'].tolist()

# Vectorize QA and Small Talk data separately
qa_vectorizer = TfidfVectorizer()
qa_question_vectors = qa_vectorizer.fit_transform(questions)

small_talk_vectorizer = TfidfVectorizer()
small_talk_question_vectors = small_talk_vectorizer.fit_transform(small_talk_questions)

# Instantiate RecipeSearchBot for recipe handling
recipe_bot_instance = RecipeSearchBot(db_name='recipes.db')

# Global variables for identity management
user_name = db.get_user_data('user_name')  
if user_name:
    print(f"Welcome back, {user_name}!")
else:
    user_name = None
name_expected = False
name_already_known = bool(user_name)


def match_small_talk(user_input):
    """
    Match user input to small talk queries using cosine similarity.
    Args:
        user_input (str): The user's input message.
    Returns:
        int or None: Index of the best match if found, otherwise None.
    """
    input_vector = small_talk_vectorizer.transform([user_input])
    similarities = cosine_similarity(input_vector, small_talk_question_vectors).flatten()

    confidence_threshold = 0.4
    best_match_index = similarities.argmax()
    best_match_score = similarities[best_match_index]

    if best_match_score >= confidence_threshold:
        return best_match_index
    return None


def match_qa(user_input):
    """
    Match user input to Q&A queries using cosine similarity.
    Args:
        user_input (str): The user's input message.
    Returns:
        int or None: Index of the best match if found, otherwise None.
    """
    input_vector = qa_vectorizer.transform([user_input])
    cosine_similarities = cosine_similarity(input_vector, qa_question_vectors).flatten()

    confidence_threshold = 0.7
    best_match_index = cosine_similarities.argmax()
    best_match_score = cosine_similarities[best_match_index]

    if best_match_score >= confidence_threshold:
        return best_match_index
    return None


def analyse_sentiment_response(user_input):
    """
    Analyze user's response for sentiment and common reaction patterns.

    Returns appropriate response based on the sentiment.
    """
    # Convert to lowercase for pattern matching
    text = user_input.lower()
    
    # Check for explicit positive reactions
    positive_patterns = {
        r'\b(ha|haha|heh|lol|lmao|rofl)\b': [
            "Glad you found that funny! 😄",
            "I love making people laugh! 😊",
            "Haha, I try my best to keep things entertaining! 😄",
            "Nothing better than sharing a laugh! 😊"
        ],
        r'\b(funny|hilarious|good one)\b': [
            "Thanks! I do have a good sense of humor! 😊",
            "I'm happy you enjoyed that! 😄",
            "Humor makes conversations better, don't you think? 😊",
            "I try to keep things light and fun! 😄"
        ]
    }
    
    # Check for pattern matches 
    for pattern, responses in positive_patterns.items():
        if re.search(pattern, text):
            return random.choice(responses)
    
    # If no pattern match, analyse sentiment
    blob = TextBlob(text)
    sentiment = blob.sentiment.polarity
    
    if sentiment > 0.3:
        return random.choice([
            "Thanks for the positive vibes! 😊",
            "Glad you're enjoying our chat! 😄",
            "That's the spirit! 😊",
            "Your enthusiasm is contagious! 😄"
        ])
    elif sentiment < -0.3:
        return random.choice([
            "I'll try to do better next time! 😊",
            "Sorry if that wasn't what you were looking for.",
            "Let me know how I can help better!",
            "Perhaps we could try a different topic?"
        ])
    
    return None    


def match_intent(user_input):
    """
    Determines the user's intent from their input message.
    
    Analyses the input text against known patterns and previous context
    to identify the most likely user intent.
    
    Args:
        user_input (str): The user's message text
        
    Returns:
        tuple: (match_index, intent_type, [optional_sentiment_response])
            match_index: Index of matched pattern or None
            intent_type: Identified intent category
            sentiment_response: Optional sentiment-based response
    """
    user_input_lower = user_input.lower()
    
    qa_index = match_qa(user_input)
    if qa_index is not None:
        return qa_index, "question_answering"

    
    # Recipe Query 
    recipe_patterns = [
        r"\b(?:what is |show me |get |find )(?:the )?recipe for\s+([a-z\s]+)",
        r"\bhow (?:do I|to) (?:cook|make|prepare)\s+([a-z\s]+)",
        r"\brecipe (?:for|to make)\s+([a-z\s]+)",
        r"\b(?:teach|show) me how to (?:cook|make|prepare)\s+([a-z\s]+)",
        r"\b(?:want|need|looking) (?:the )?recipe (?:for|to make)\s+([a-z\s]+)",
        r"\bhow to (?:cook|make)\s+([a-z\s]+)",
        r"\bmake\s+([a-z\s]+)"
    ]

    # Ingredients Query 
    ingredients_patterns = [
        r"(?:what are |list |show |tell me |get )(?:the )?ingredients(?: for| of)?\s*(.+)?",
        r"what (?:do I|items do I|things do I) need(?: for| to make)?\s*(.+)?",
        r"(?:ingredients|what goes|what's needed|what's required) (?:to make|for|in|to cook)\s*(.+)?",
        r"(?:what|which) ingredients (?:do I need|are needed|go into|are used in)\s*(.+)?",
        r"(?:what's|whats|what is) (?:in|inside|used in)\s*(.+)?",
        r"(?:show|tell|list) (?:me )?(?:what|which) ingredients\s*(.+)?",
        r"what do I need to buy for\s*(.+)?",
        r"ingredients\s+(?:of|for|to make)\s*(.+)",
        r"what goes in\s*(.+)",
        r"^(?:ingredients|what do I need)\??$",
        r"^(?:show|tell|list)(?:\s+me)? the ingredients\??$",
        r"^what do I need for (?:it|this)\??$",
        r"^what's needed\??$",
        r"^show(?:\s+me)? what I need\??$"
    ]

    # Save Favorites
    save_patterns = [
        r"^save (?:this|the) recipe$",
        r"^add (?:this|it) to (?:my )?favorites?$",
        r"(?:can you |please |could you )?save this(?:\s+recipe)?",
        r"(?:can you |please |could you )?add this to (?:my )?favorites?",
        r"^save it$",
        r"^add to favorites?$"
    ]

    # Primary recipe-related intents
    # Check for ingredient listing requests
    for pattern in ingredients_patterns:
        if re.search(pattern, user_input_lower):
            return None, "ingredients_query"

    # Check for recipe lookup/search requests
    for pattern in recipe_patterns:
        if re.search(pattern, user_input_lower):
            return None, "recipe_query"

    # Check for recipe saving/favoriting requests
    for pattern in save_patterns:
        if re.search(pattern, user_input_lower):
            return None, "save_favorites"

    # Recipe discovery/suggestion requests
    if re.search(r"(?:what\s(?:[a-z]+\s)?recipes\sdo\s(?:you\s)?(?:have|know)|suggest\s(?:a|some|any|recipes)\s(?:for\s)?(?:[a-z\s]+))", user_input_lower):
        return None, "suggest_recipes"

    # Check for emotional responses or reactions
    sentiment_response = analyse_sentiment_response(user_input)
    if sentiment_response:
        return None, "sentiment_response", sentiment_response

    # Check for cooking instructions/directions
    if re.search(r"\b(how can i cook|how do i prepare|directions for|what are the directions( for)?)\b", user_input_lower):
        return None, "directions_query"

    # Check for favorite recipe deletion requests
    if re.search(r"(?:delete|remove)\s+(.+?)(?:\s+from\s+(?:my\s+)?(?:favorites?|favourites?)|$)", user_input_lower):
        return None, "delete_favorites"

    # Check for identity/name-related queries
    if re.search(r"(what'?s?\s+my\s+name|what\s+is\s+my\s+name|who am i|my name is|call me|i am)", user_input_lower):
        return None, "identity"

    # Check for greetings
    if re.search(r"\b(hi|hello|hey)\b", user_input_lower):
        return None, "greeting"

    # Check for expressions of gratitude
    if re.search(r"\b(thank you|thanks|appreciate it)\b", user_input_lower):
        return None, "gratitude"

    # Check for date/time queries
    if re.search(r"\b(whats?\s+the\s+(date|time))\b", user_input_lower):
        return None, "date_time"

    # Check for favorite recipe listing requests
    if re.search(r"(my saved recipes|list my recipes|show favourites|saved recipes|favorite recipes)", user_input_lower):
        return None, "list_favorites"

    # Check for small talk patterns
    small_talk_index = match_small_talk(user_input)
    if small_talk_index is not None:
        return small_talk_index, "small_talk"

    # Default fallback for unrecognized inputs
    return None, "fallback"


def manage_identity(user_input):
    """
    Manage user identity by storing, retrieving, and responding to user identity-related queries.
    Args:
        user_input (str): The user's input message.
    Returns:
        str: A response message related to the user's identity.
    """
    global user_name, name_expected, name_already_known

    # Handle user providing their name
    name_match = re.search(r"^(?:my name is|call me|i am)\s+([A-Za-z]+)$", user_input.strip(), re.I)
    if name_match:
        user_name = name_match.group(1).capitalize()
        db.save_user_data("user_name", user_name)
        name_expected = False
        name_already_known = True
        return f"Nice to meet you, {user_name}!"

    # Handle queries asking about the user's name
    if re.search(r"(?:what'?s?\s+my\s+name|what\s+is\s+my\s+name|who am i)", user_input.lower()):
        if user_name:
            return f"Your name is {user_name}."
        return "I don't know your name yet. Please tell me!"

    # If the bot is explicitly expecting the user's name
    if name_expected and re.match(r"^[A-Za-z]+$", user_input.strip()):
        user_name = user_input.capitalize()
        db.save_user_data("user_name", user_name)
        name_expected = False
        name_already_known = True
        return f"Got it, {user_name}! How can I help you today?"

    # If no name is known and the bot wasn't explicitly expecting one, prompt the user
    if not name_already_known:
        name_expected = True
        return "Hi there! By the way, what's your name?"

    # Default fallback
    return "I'm here to remember your name if you tell me!"


def handle_recipe_query(user_input):
    """
    Process user requests for recipes and return the full recipe details.
    
    Args:
        user_input (str): The user's message containing a recipe request
        
    Returns:
        str: Either the complete recipe details (title, ingredients, directions) 
             or an error message if recipe not found
    """
    global context
    
    # Check if the input contains any recipe-related keywords
    match = re.search(r"\b(recipe|how to cook|ingredients for|how to make)\b", user_input)
    if not match:
        return "I didn't understand your recipe request. Can you rephrase?"

    # Split input at the keyword to isolate the recipe name
    command = match[0]
    query = user_input.split(command, 1)[-1].strip()
    result = recipe_bot_instance.search_recipe(query)

    if isinstance(result, dict):
        # Store recipe details in context for follow-up questions
        context.update({
            "last_recipe_title": result["title"],
            "last_recipe_ingredients": result["ingredients"],
            "last_recipe_directions": result["directions"]
        })
        
        # Format and return the complete recipe
        return (
            f"\nRecipe: {result['title']}\n"
            f"Ingredients: {', '.join(result['ingredients'])}\n"
            f"Directions: {' '.join(result['directions'])}"
        )
    return result


def handle_ingredients_query(user_input):
    """
    Process user requests for recipe ingredients.
    
    Args:
        user_input (str): The user's message requesting ingredients
        
    Returns:
        str: Either the ingredients list for the requested recipe
             or an error message if recipe not found
             
    Handles three cases:
    1. Follow-up questions about the last discussed recipe
    2. Direct questions about a specific recipe's ingredients
    3. Generic ingredient questions with context from previous conversation
    """
    global context
    user_input_lower = user_input.lower()
    
    # Case 1: Handle follow-up questions about current recipe
    if context.get("last_recipe_title"):
        # Common patterns for follow-up ingredient questions
        context_patterns = [
            r"^(?:ingredients|what do I need)\??$",
            r"^(?:show|tell|list)(?:\s+me)? the ingredients\??$",
            r"^what goes in(?:to)? (?:it|this)\??$",
            r"^what do I need for (?:it|this)\??$",
            r"^what's needed\??$",
            r"^show(?:\s+me)? what I need\??$"
        ]
        if any(re.search(pattern, user_input_lower) for pattern in context_patterns):
            return f"The ingredients for {context['last_recipe_title']} are: {', '.join(context['last_recipe_ingredients'])}."
    
    # Case 2: Handle direct questions about specific recipes
    match = re.search(r"(?:for|of|make|in|into)\s+(.+?)(?:\?|\s*$)", user_input_lower)
    if match:
        query_title = match.group(1).strip()
        result = recipe_bot_instance.search_recipe(query_title)
        
        if isinstance(result, dict):
            # Update context with new recipe details
            context.update({
                "last_recipe_title": result["title"],
                "last_recipe_ingredients": result["ingredients"],
                "last_recipe_directions": result["directions"]
            })
            return f"The ingredients for {result['title']} are: {', '.join(result['ingredients'])}."
    
    # Case 3: Handle generic ingredient questions using context
    if context.get("last_recipe_title") and "ingredient" in user_input_lower:
        return f"The ingredients for {context['last_recipe_title']} are: {', '.join(context['last_recipe_ingredients'])}."
    
    return "I couldn't find that recipe. Could you try another one?"


def handle_suggest_recipes(user_input):
    """
    Handle user requests for recipe suggestions based on keywords.
    Args:
        user_input (str): The user's input message.
    Returns:
        str: A response containing suggested recipes or an error message.
    """
    match = re.search(r"(?:what|suggest|do you have|any)\s+(\w+)\s+(?:recipes|dishes|foods)?", user_input.lower())
    if match:
        keyword = match.group(1).strip()

        # get recipes based on the detected keyword
        recipe_list = recipe_bot_instance.search_recipes_by_keyword(keyword)

        if recipe_list:
            # Randomly select up to 10 recipes
            num_recipes = min(10, len(recipe_list))
            random_recipes = random.sample(recipe_list, num_recipes)
            
            recipe_titles = [recipe['title'] for recipe in random_recipes]
            return f"Some {keyword} recipes I know are: {', '.join(recipe_titles)}. Which one would you like to know more about?"
        else:
            return f"Sorry, I don't know any {keyword} recipes. Try another type!"
    else:
        return "I didn't catch that. Can you specify a type of recipe you'd like?"


def handle_delete_favorites(user_input):
    """
    Process requests to remove recipes from a user's favorites list.    
    Args:
        user_input (str): The user's message requesting recipe deletion
    Returns:
        str: A response indicating:
            - Success/failure of deletion
            - Request for user identification if needed
            - Request for recipe specification if needed
    """
    # Need to know who's asking to delete the recipe
    if not user_name:
        return "Please tell me your name first!"
    
    # Try to find which recipe user wants to delete
    match = re.search(r"(?:delete|remove)\s+(.+?)(?:\s+from\s+(?:my\s+)?(?:favorites?|favourites?)|$)", user_input.lower())
    if not match:
        return "Please specify which recipe you'd like to delete from your favorites."
    
    # Get the recipe name and try to delete it
    title = match.group(1).strip()
    return recipe_bot_instance.delete_from_favorites(user_name, title)


def handle_directions_query(user_input):
    """
    Handle queries for recipe directions.
    
    Args:
        user_input (str): User's query about recipe directions
        
    Returns:
        str: Cooking directions or appropriate error message
    """
    global context
    
    # If just asking for directions or recipe name only
    if re.match(r"^(?:what are the directions|how do i cook it)\??$", user_input.lower()) or re.match(r"^[\w\s]+$", user_input):
        if context.get("last_recipe_title") and context.get("last_recipe_directions"):
            return f"The directions for {context['last_recipe_title']} are: {' '.join(context['last_recipe_directions'])}."
        return "Please specify which recipe's directions you'd like to know about."

    # get recipe name from query
    match = re.search(r"\b(?:how do I cook|directions for|how to make|how to prepare)\s+(.+)", user_input.lower())
    if match:
        query_title = match.group(1).strip()
        result = recipe_bot_instance.search_recipe(query_title)
        
        if isinstance(result, dict):
            context.update({
                "last_recipe_title": result["title"],
                "last_recipe_ingredients": result["ingredients"],
                "last_recipe_directions": result["directions"]
            })
            return f"The directions for {result['title']} are: {' '.join(result['directions'])}."
    
    return "I couldn't find directions for that recipe. Could you try another one?"


def handle_save_favorites():
    """
    Save the currently discussed recipe to the user's favorites.
    Returns:
        str: A response indicating whether the recipe was saved successfully.
    """
    if not user_name:
        return "Please tell me your name first so I can save this recipe for you!"

    title = context.get("last_recipe_title", "").strip()
    ingredients = context.get("last_recipe_ingredients", [])
    directions = context.get("last_recipe_directions", [])

    if not title:
        return "There is no recipe currently being discussed to save. Ask me for a recipe first!"

    if not ingredients or not directions:
        return f"Cannot save '{title}' because ingredients or directions are missing."

    response = recipe_bot_instance.save_recipe_to_favorites(user_name, title, ingredients, directions)
    return response


def handle_list_favorites():
    """
    Retrieve and list the user's favorite recipes.
    Returns:
        str: A response containing the list of saved recipes or an error message.
    """
    if not user_name:
        return "Please tell me your name first so I can look up your saved recipes!"

    response = recipe_bot_instance.get_favorites(user_name)
    return response if response else "No recipes found in your favorites."


def get_date_time_response():
    """
    Provide the current date and time.
    Returns:
        str: A response containing the current date and time.
    """
    current_datetime = datetime.now()
    return f"Today's date is {current_datetime.strftime('%Y-%m-%d')}, and the current time is {current_datetime.strftime('%H:%M:%S')}."


def answer_question(best_match_index):
    """
    Provide an answer to a user question based on the best match index.
    Args:
        best_match_index (int): The index of the best-matching question in the dataset.
    Returns:
        str: A response containing the answer or an error message.
    """
    return answers[best_match_index] if best_match_index is not None else "Sorry, I don't have an answer for that yet."


def chatbot_response(user_input):
    """
    Main function to handle chatbot responses based on user input.
    Args:
        user_input (str): The user's input message.
    Returns:
        str: A response generated by the chatbot based on the detected intent.
    """
    global name_expected, user_name, name_already_known

    if name_expected:
        return manage_identity(user_input)

    best_match_index, intent, *extra_args = match_intent(user_input) + (None,)

    # Handle sentiment responses
    if intent == "sentiment_response":
        return extra_args[0] 

    # Handle different intents
    if intent == "greeting":
        greetings = [
            f"Hi there, {user_name}! How can I help you today?",
            f"Hello {user_name}! Looking for some culinary inspiration?",
            f"Hey {user_name}! What's cooking?",
            f"Welcome back {user_name}! How can I help in the kitchen today?"
        ] if user_name else [
            "Hi there! By the way, what's your name?",
            "Hello! Would you mind telling me your name?",
            "Hey! I'd love to know your name first!"
        ]
        return random.choice(greetings)
    elif intent == "gratitude":
        recipe_related_intents = ["recipe_query", "ingredients_query", "directions_query"]
        thanks_responses = [
            "You're welcome! Let me know how the recipe turns out!",
            "Enjoy cooking! Hope the dish turns out great!",
            "Happy cooking! Don't forget to save it if you like it!",
            "Anytime! Would love to hear how it goes!"
        ] if context["last_intent"] in recipe_related_intents else [
            "You're welcome!",
            "Anytime!",
            "Glad I could help!",
            "No problem at all!"
        ]
        return random.choice(thanks_responses)

    # Set last intent for future responses
    context["last_intent"] = intent

    # Intent handlers
    if intent == "recipe_query":
        return handle_recipe_query(user_input)
    elif intent == "suggest_recipes":
        return handle_suggest_recipes(user_input)
    elif intent == "ingredients_query": 
        return handle_ingredients_query(user_input)
    elif intent == "directions_query":
        return handle_directions_query(user_input)
    elif intent == "date_time":
        return get_date_time_response()
    elif intent == "question_answering":
        return answers[best_match_index] if best_match_index is not None else "Sorry, I don't have an answer for that yet."
    elif intent == "small_talk":
        return small_talk_responses[best_match_index]
    elif intent == "identity":
        return manage_identity(user_input)
    elif intent == "save_favorites":
        return handle_save_favorites()
    elif intent == "list_favorites":
        return handle_list_favorites()
    elif intent == "delete_favorites":
        return handle_delete_favorites(user_input)
    elif intent == "fallback":
        return "I'm not sure how to respond to that. Try asking something else!"
    
if __name__ == "__main__":
    print("Bot: Hello! I am your assistant bot.")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["bye", "quit", "exit"]:
            print("Goodbye!")
            break
        response = chatbot_response(user_input)
        print("Bot:", response)