from nltk.corpus import wordnet
from nltk.metrics.distance import edit_distance
import sqlite3

def expand_query(query, context="general"):
    """
    Expand a search query by adding synonyms and handling potential typos using WordNet.
    
    This function performs three main operations:
    1. Filters out common stop words
    2. Adds WordNet synonyms for meaningful terms
    3. Includes similar words to handle potential typos
    
    Args:
        query (str): The original search query from the user
        context (str, optional): Context for query expansion. Defaults to "general"
            (Reserved for future context-specific expansions)
    
    Returns:
        str: Space-separated string of expanded search terms
    """
    stop_words = {"for", "a", "the", "do", "can", "you", "give"}
    words = query.lower().split()
    expanded_terms = set()
    
    # Handle potential typos
    for word in words:
        if len(word) > 2 and word not in stop_words:
            # Add original word
            expanded_terms.add(word)
            
            # Add WordNet synonyms
            for syn in wordnet.synsets(word):
                for lemma in syn.lemmas():
                    synonym = lemma.name().replace('_', ' ')
                    expanded_terms.add(synonym)
            
            # Add close matches for potential typos
            for syn in wordnet.synsets(word):
                for similar_word in syn.lemma_names():
                    # Allow 2 character differences
                    if edit_distance(word, similar_word) <= 2:  
                        expanded_terms.add(similar_word)

    return " ".join(expanded_terms)


def normalize_titles(db_name='recipes.db'):
    """
    Normalize the titles in the 'recipes_final' table by trimming whitespace
    and converting them to lowercase.

    Parameters:
    - db_name (str): The name of the SQLite database (default is 'recipes.db').
    """
    connection = sqlite3.connect(db_name)
    cursor = connection.cursor()
    cursor.execute("SELECT id, title FROM recipes_final")
    recipes = cursor.fetchall()

    for recipe in recipes:
        recipe_id, title = recipe
        # Ensure title is not None
        if title:  
            normalized_title = title.strip().lower()
            cursor.execute("UPDATE recipes_final SET title = ? WHERE id = ?", (normalized_title, recipe_id))

    connection.commit()
    connection.close()
