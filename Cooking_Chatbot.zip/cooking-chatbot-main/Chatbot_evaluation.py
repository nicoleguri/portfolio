from chatbot import chatbot_response, recipe_bot_instance
from sklearn.metrics import classification_report, precision_recall_fscore_support
import numpy as np
import time
from datetime import datetime
from chatbot import match_intent
import unittest
from chatbot import chatbot_response, context, recipe_bot_instance, db

class ChatbotEvaluator:
    """
    Evaluate the chatbot's performance in different scenarios, 
    for intent classification, recipe search, conversation flow, 
    question answering and small talk. 
    """
    def __init__(self):
        self.test_intents = {
            "greeting": [
                "hello", "hi", "hey", "good morning",
            ],
            "recipe_query": [
                "what soup recipes do you have",
                "what is the recipe for hamburger soup",
                "recipe for chocolate cake", 
                "how to cook brown rice",
                "give me a recipe for cookies", 
                "what rice recipes do you have"
            ],
            "ingredients_query": [
                "what are the ingredients for Hamburger Soup",
                "what are the ingredients",
                "what do i need to make soup",
                "ingredients of pizza",
                "what ingredients are in chicken soup",
                "show me what i need for pasta"
            ],
            "small_talk": [
                "how are you",
                "what can you do",
                "tell me a joke", 
                "who are you", 
                "can you sing",
                "how are you doing",
                "how are you today",
                "are you human",
                "what's your name",
                "where are you from",
                "funny",
                "do you eat food",
                "are you real",
                "good one",
            ],
            "save_favorites": [
                "save this recipe",
                "add to favorites",
                "save recipe",
                "add this to my favorites"
            ],
            "list_favorites": [
                "show my saved recipes", 
                "list my favourites",
                "list my recipes", 
                "show my favorite recipes"
            ],
            "suggest_recipes": [
                "suggest some pasta recipes",
                "what soup recipes do you have",
                "what cake recipes do you have",
                "show me some dessert recipes"
            ],
            "question_answering": [
                "how does a water pump work",
                "how much is a tablespoon of water",
                "how are antibodies used",
                "what causes heart disease",
                "how was the moon formed",
                "what is emotional intelligence",
                "how long should I cook pasta",
                "when did anne frank die",
                "what are bonds"
            ],
            "sentiment_response": [
                "this recipe looks delicious",
                "can't wait to try this",
                "sounds yummy",
                "this will be perfect",
                "just what I was looking for",
                "this seems too difficult",
                "not what I expected",
                "too many ingredients",
                "takes too long",
                "too complicated for me",
                "good recipe but too complex",
                "nice but time consuming",
                "looks good but expensive ingredients",
                "nice",
                "cool",
                "ok",
                "meh"
            ],
            "fallback": [
                "xyz123",
                "asdfghjkl",
                "qwerty123",
                "randomtext",
                "!@#$%^",
                "999999",
                "blablabla",
                "nonsenseword",
                "gibberish text here",
                "random456"
            ],
            "gratitude": [
                "thank you",
                "thanks a lot",
                "appreciate it",
                "thanks for your help",
                "that's helpful, thanks",
                "thx",
                "tysm",
                "thank you so much",
                "thanks!",
                "great, thank you"
            ]
        }

        self.test_recipes = [
            ("cake", ["Rhubarb Coffee Cake", "Chocolate cake", "Gooey Coffee Cake"]),
            ("soup", ["Jewell Ball'S Chicken", "Broccoli Dip For Crackers", "Chicken Casserole"]),
            ("pasta", ["Pasta Chicken Salad(268 Calories Per Serving)", "Easy Chicken Cacciatore", "Penne Al'Arrabbiato"]),
            ("salad", ["Taco Salad Chip Dip", "Three Bean Salad", "Broccoli Salad"]),
            ("rice", ["Brown Rice", " Beef And Spanish Rice Casserole", "Smoked Turkey Risotto"])
        ]

        self.test_identity_intents = [
            ("my name is Alice", "identity"),
            ("Bob", "identity"),
            ("i am Charlie", "identity"),
            ("call me David", "identity"),
            ("who am i", "identity"),
            ("what's my name", "identity")
        ]


    def evaluate_intent_classification(self):
        """
        Evaluates the chatbot's intent classification performance across different contexts.
        
        Returns:
            dict: Contains evaluation metrics including:
                - precision: Overall precision score
                - recall: Overall recall score
                - f1: F1 score
                - avg_response_time: Average time to classify intents
                - context_accuracy: How well context is maintained
                - detailed_report: Detailed classification metrics
        """
        true_intents = []
        predicted_intents = []
        response_times = []
        context_tracking = []

        # Test each intent in different contexts
        for intent, queries in self.test_intents.items():
            for query in queries:
                # Test with different context states to evaluate context handling
                contexts = [
                    {"last_recipe_title": "Smoked Turkey Risotto"},
                    {"last_recipe_title": None},
                    {"last_intent": "greeting"},
                    {"last_intent": None} 
                ]
                
                for context_state in contexts:
                    global context
                    context.update(context_state)
                    
                    # Measure response time and accuracy
                    start_time = time.time()
                    best_match_index, predicted_intent, *_ = match_intent(query)
                    end_time = time.time()
                    
                    # Record results for analysis
                    true_intents.append(intent)
                    predicted_intents.append(predicted_intent)
                    response_times.append(end_time - start_time)
                    context_tracking.append(
                        predicted_intent == intent and 
                        context_state.get("last_intent") is not None
                    )

        # Add identity intents to the evaluation
        for query, expected_intent in self.test_identity_intents:
            best_match_index, predicted_intent, *_ = match_intent(query)
            true_intents.append(expected_intent)
            predicted_intents.append(predicted_intent)

        # Calculate comprehensive metrics
        precision, recall, f1, _ = precision_recall_fscore_support(
            true_intents, 
            predicted_intents, 
            average='weighted'
        )
        
        context_score = sum(context_tracking) / len(context_tracking)
        
        return {
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'avg_response_time': np.mean(response_times),
            'context_accuracy': context_score,
            'detailed_report': classification_report(true_intents, predicted_intents)
        }


    def evaluate_recipe_search(self):
        """
        Evaluates the recipe search functionality including relevance and response time.
        
        Tests both exact and partial matching of recipe titles, considering variations
        in naming and spelling.
        
        Returns:
            dict: Contains search evaluation metrics including:
                - average_precision: Mean precision across all queries
                - average_recall: Mean recall across all queries
                - f1_score: Harmonic mean of precision and recall
                - avg_response_time: Average search response time
        """
        precisions = []
        recalls = []
        response_times = []

        for query, relevant_recipes in self.test_recipes:
            start_time = time.time()
            results = recipe_bot_instance.search_recipes_by_keyword(query)
            end_time = time.time()
            response_times.append(end_time - start_time)

            retrieved_recipes = [r['title'].lower() for r in results]
            relevant_recipes = [r.lower() for r in relevant_recipes]

            # Add partial matching
            partial_matches = set()
            for retrieved in retrieved_recipes:
                for relevant in relevant_recipes:
                    if (retrieved in relevant.lower() or 
                        relevant.lower() in retrieved):
                        partial_matches.add(retrieved)
            
            # Update metrics calculation
            retrieved_relevant = partial_matches | (set(retrieved_recipes) & 
                               set(r.lower() for r in relevant_recipes))
            
            precision = len(retrieved_relevant) / len(retrieved_recipes) if retrieved_recipes else 0
            recall = len(retrieved_relevant) / len(relevant_recipes) if relevant_recipes else 0

            precisions.append(precision)
            recalls.append(recall)

        avg_precision = np.mean(precisions)
        avg_recall = np.mean(recalls)
        f1 = 2 * (avg_precision * avg_recall) / (avg_precision + avg_recall) if (avg_precision + avg_recall) > 0 else 0
        avg_response_time = np.mean(response_times)

        return {
            'average_precision': avg_precision,
            'average_recall': avg_recall,
            'f1_score': f1,
            'avg_response_time': avg_response_time
        }


    def evaluate_conversation_flow(self):
        """
        Evaluates the chatbot's ability to maintain context and handle multi-turn conversations.
        
        Tests various conversation scenarios including:
        - Recipe search and save workflows
        - Multiple recipe inquiries
        - Error recovery paths
        - Context retention across turns
        
        Returns:
            dict: Contains conversation metrics including:
                - conversation_success_rate: Proportion of successful conversation flows
        """
        conversation_tests = [
            # Recipe search and save flow
            [
                "hello",
                "what rice recipes do you have",
                "show me the recipe for brown rice",
                "what are the ingredients for brown rice",
                "save this recipe",
                "list my recipes"
            ],
            # Multiple recipe inquiry flow
            [
                "hi",
                "what pasta recipes do you have",
                "what are the directions for penne al'arrabbiato",
                "what ingredients do i need",
                "what are the steps",
                "what are the directions"
                "thanks that's helpful"
            ],
            # Error recovery flow
            [
                "show me nonexistent recipe",
                "sorry, show me pasta recipes instead",
                "what are the ingredients for spaghetti",
                "save this recipe"
            ]
        ]

        flow_scores = []
        for conversation in conversation_tests:
            context_maintained = True
            previous_response = None
            for query in conversation:
                response = chatbot_response(query)
                if not response or response == "I'm not sure how to respond to that.":
                    if previous_response and "not sure" in previous_response.lower():
                        context_maintained = False
                        break
                previous_response = response
            flow_scores.append(context_maintained)

        return {
            'conversation_success_rate': sum(flow_scores) / len(flow_scores)
        }


    def generate_detailed_report(self):
        """
        Generates a comprehensive evaluation report covering the chatbot performance.
        
        Returns:
            dict: Detailed report containing:
                - intent_accuracy: Intent classification performance
                - response_times: Timing metrics
                - context_switches: Context handling effectiveness
                - error_recovery: Error handling capabilities
                - conversation_success: Conversation flow metrics
                - database_operations: Database interaction performance
        """
        report = {
            'intent_accuracy': {},
            'response_times': {},
            'context_switches': {},
            'error_recovery': {},
            'conversation_success': {},
            'database_operations': {}
        }
        
        return report


    def evaluate_identity_management(self):
        """
        Evaluates the chatbot's ability to manage user identity.
        
        Returns:
            dict: Contains identity management evaluation metrics including:
                - correct_name_recognition: Proportion of correct name recognition
                - correct_name_recall: Proportion of correct name recall
        """
        print("\nEvaluating Identity Management...")
        correct_name_recognition = 0
        correct_name_recall = 0
        total_tests = 0

        # Reset global variables before testing
        global user_name, name_expected, name_already_known
        user_name = None 
        name_expected = False
        name_already_known = False

        # Test cases for identity management
        identity_tests = [
            ("my name is Alice", "Nice to meet you, Alice!"),
            ("what's my name", "Your name is Alice."),
            ("Bob", "Got it, Bob! How can I help you today?"),  # Expecting name
            ("who am i", "Your name is Bob."),
            ("i am Charlie", "Nice to meet you, Charlie!"),
            ("what is my name", "Your name is Charlie."),
            ("David", "Got it, David! How can I help you today?"),  # Expecting name
            ("my name is Erin", "Nice to meet you, Erin!"),
            ("what's my name", "Your name is Erin.")
        ]

        for user_input, expected_response in identity_tests:
            response = chatbot_response(user_input)
            if expected_response in response:
                if "Nice to meet you" in expected_response or "Got it" in expected_response:
                    correct_name_recognition += 1
                else:
                    correct_name_recall += 1
            total_tests += 1

        return {
            'correct_name_recognition': correct_name_recognition / (total_tests / 2),  # Half the tests are for recognition
            'correct_name_recall': correct_name_recall / (total_tests / 2)  # Half the tests are for recall
        }


def run_full_evaluation():
    """
    Run all evaluations and generate a report
    """
    evaluator = ChatbotEvaluator()
    
    # Create evaluation report
    report = f"Chatbot Evaluation Report - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
    report += "=" * 50 + "\n\n"

    # Intent Classification
    intent_metrics = evaluator.evaluate_intent_classification()
    report += "\nDetailed Classification Report:\n"
    report += intent_metrics['detailed_report'] + "\n"

    # Save report
    with open('evaluation_report.txt', 'w') as f:
        f.write(report)

    print("\nEvaluation completed! Results saved to 'evaluation_report.txt'")
    return report


class ChatbotEvaluationTest(unittest.TestCase):
    """
    Comprehensive test suite for evaluating chatbot functionality.
    
    Tests cover:
    - Intent classification
    - Recipe search and management
    - Conversation flow
    - Error handling
    - Context management
    - Performance metrics
    """
    def setUp(self):
        global context
        context = {
            "last_recipe_title": None,
            "last_recipe_ingredients": None,
            "last_recipe_directions": None,
            "last_intent": None,
        }


    def test_intents(self):
        """
        Tests the chatbot's ability to correctly classify and respond to different intents.
        Covers recipe-related queries, favorites management, small talk, and sentiment responses.
        """
        # Recipe related intents
        self.assertIn("recipe", chatbot_response("how do I make pasta").lower())
        self.assertIn("ingredients", chatbot_response("what are the ingredients for pizza").lower())
        self.assertIn("recipe", chatbot_response("suggest some Italian recipes").lower())
        self.assertIn("directions", chatbot_response("how do I cook chicken curry").lower())

        # Favorites management
        self.assertIn("name", chatbot_response("save this recipe").lower())
        self.assertIn("name", chatbot_response("show my favorites").lower())
        self.assertIn("name", chatbot_response("delete pasta from favorites").lower())

        # Small talk and general queries
        self.assertIn("time", chatbot_response("what's the time").lower())
        self.assertIn("welcome", chatbot_response("thank you").lower())
        self.assertIn("hi", chatbot_response("hello").lower())

        # Sentiment responses
        self.assertIn("", chatbot_response("haha that's funny"))
        self.assertIn("better", chatbot_response("that's not helpful").lower())

        # Add tests for these missing intents:
        self.assertIn("directions", chatbot_response("how do I prepare pasta").lower())
        self.assertIn("directions", chatbot_response("what are the steps for making pizza").lower())
        
        self.assertIn("time", chatbot_response("what time is it").lower())
        self.assertIn("date", chatbot_response("what's today's date").lower())
        
        self.assertIn("😊", chatbot_response("that's really helpful").lower())
        self.assertIn("better", chatbot_response("that's not what I wanted").lower())


    def test_error_handling(self):
        """
        Tests the chatbot's response to invalid inputs and edge cases.
        Verifies appropriate error messages and recovery mechanisms.
        """
        # Test invalid recipe queries
        self.assertIn("couldn't find", chatbot_response("how do I make xyzabc123").lower())
        
        # Test empty favorites
        self.assertIn("name", chatbot_response("list my favorites").lower())
        
        # Test invalid ingredient queries
        self.assertIn("couldn't find", chatbot_response("what are the ingredients for nonexistent dish").lower())


    def test_context_management(self):
        """
        Tests the chatbot's ability to maintain and utilize conversation context.
        Verifies context retention across multiple turns and appropriate context clearing.
        """
        # Test recipe context retention
        chatbot_response("how do I make pasta")
        follow_up = chatbot_response("what are the ingredients")
        self.assertIn("pasta", follow_up.lower())

        # Test context clearing
        chatbot_response("how do I make pizza")
        self.assertEqual(context["last_recipe_title"].lower(), "pizza")


    def test_database_operations(self):
        """
        Tests database interactions for recipe favorites management.
        Verifies:
        - Saving recipes to favorites after setting username
        - Listing saved favorites
        - Deleting recipes from favorites
        """
        # Test saving to favorites
        chatbot_response("my name is TestUser")
        chatbot_response("how to make pasta")
        save_response = chatbot_response("save this recipe")
        self.assertNotIn("error", save_response.lower())

        # Test listing favorites
        list_response = chatbot_response("show my favorites")
        self.assertIn("pasta", list_response.lower())

        # Test deleting from favorites
        delete_response = chatbot_response("delete pasta from favorites")
        self.assertIn("removed", delete_response.lower())


    def test_conversation_flow(self):
        """
        Tests basic conversation flow and context maintenance.
        Verifies the chatbot can handle a typical conversation sequence:
        greeting -> name collection -> recipe query
        """
        # Test greeting -> name -> recipe flow
        self.assertIn("name", chatbot_response("hi").lower())
        self.assertIn("nice", chatbot_response("my name is Alice").lower())
        self.assertIn("recipe", chatbot_response("how do I make soup").lower())


    def test_input_validation(self):
        """
        Tests chatbot's handling of invalid or edge-case inputs.
        Verifies appropriate responses for:
        - Empty inputs
        - Special characters
        - Extremely long inputs
        """
        # Test empty input
        self.assertIn("not sure", chatbot_response("").lower())
        
        # Test special characters
        self.assertIn("not sure", chatbot_response("@#$%").lower())
        
        # Test very long input
        long_input = "a" * 1000
        self.assertIn("not sure", chatbot_response(long_input).lower())


    def test_performance(self):
        """
        Tests the chatbot's response time and performance metrics.
        Ensures responses are within acceptable time limits for different query types.
        """
        def measure_response_time(query):
            """
            Measures response time for a given query.
            
            Args:
                query (str): Input query to test
                
            Returns:
                float: Response time in seconds
            """
            start_time = time.time()
            chatbot_response(query)
            return time.time() - start_time
        
        # Test response times for different query types
        recipe_time = measure_response_time("how to make pasta")
        search_time = measure_response_time("suggest Italian recipes")
        
        # Assert reasonable response times
        self.assertLess(recipe_time, 2.0) 
        self.assertLess(search_time, 3.0)


    def test_edge_cases(self):
        """
        Tests chatbot's resilience to extreme input conditions.
        Verifies handling of:
        - Extremely long repetitive inputs
        - Special character sequences
        - Empty or whitespace-only inputs
        """
        # Test extremely long inputs
        long_input = "recipe " * 100
        self.assertIn("not sure", chatbot_response(long_input).lower())
        
        # Test special characters
        special_chars = "!@#$%^&*()"
        self.assertIn("not sure", chatbot_response(special_chars).lower())
        
        # Test empty or whitespace inputs
        self.assertIn("not sure", chatbot_response("").lower())
        self.assertIn("not sure", chatbot_response("   ").lower())


    def test_complex_conversations(self):
        """
        Tests multi-turn conversation scenarios.
        Verifies:
        - Intent classification accuracy across conversation turns
        - Context maintenance in recipe-related flows
        - Proper handling of different conversation paths
        """
        # Test multi-turn conversations
        conversations = [
            [
                ("hello", "greeting"),
                ("what is the recipe for rhubarb coffee cake", "recipe"),
                ("what are the ingredients", "ingredients"),
                ("save this recipe", "save_favorites"),
                ("show my favorites", "list_favorites")
            ],
            [
                ("hi", "greeting"),
                ("suggest pasta recipes", "suggest_recipes"),
                ("how do I make the first one", "recipe"),
                ("what are the directions", "directions")
            ]
        ]
        
        for conversation in conversations:
            for query, expected_intent in conversation:
                response = chatbot_response(query)
                _, intent = match_intent(query)
                self.assertEqual(intent, expected_intent)


    def test_fallback_responses(self):
        """
        Tests chatbot's fallback mechanism for unrecognized inputs.
        Verifies:
        - Consistent "not sure" responses for nonsense inputs
        - Non-empty responses for all fallback cases
        """
        fallback_tests = [
            "xyz123",
            "qwerty",
            "random text",
            "nonsense input"
        ]
        
        for test in fallback_tests:
            response = chatbot_response(test)
            self.assertIn("not sure", response.lower())
            self.assertNotEqual(response, "")


    def test_sentiment_analysis(self):
        """
        Tests the chatbot's sentiment analysis capabilities with various inputs and contexts.
        
        Evaluates:
        - Positive/negative sentiment detection
        - Context-aware sentiment understanding
        - Emoji handling
        - Mixed sentiment recognition
        
        Returns:
            dict: Sentiment analysis performance metrics
        """
        test_cases = [
            # Test cases with context
            ({"last_intent": "recipe_query", "input": "looks delicious"}, "positive"),
            ({"last_intent": "recipe_query", "input": "too complicated"}, "negative"),
            ({"last_intent": "small_talk", "input": "haha"}, "positive"),
            ({"last_intent": "ingredients_query", "input": "perfect thanks"}, "positive"),
            # Test emoji handling
            ({"last_intent": None, "input": "👍"}, "positive"),
            ({"last_intent": None, "input": "😕"}, "negative"),
            # Test mixed sentiments
            ({"last_intent": "recipe_query", "input": "good but complex"}, "mixed"),
            # Test short responses
            ({"last_intent": None, "input": "ok"}, "neutral")
        ]
        
        results = []
        for case, expected in test_cases:
            context["last_intent"] = case["last_intent"]
            response = chatbot_response(case["input"])
            
            # Check if response matches expected sentiment
            sentiment_matched = False
            if expected == "positive":
                sentiment_matched = any(word in response.lower() for word in ["glad", "happy", "great", "wonderful"])
            elif expected == "negative":
                sentiment_matched = any(word in response.lower() for word in ["sorry", "apologize", "improve"])
            elif expected == "mixed":
                sentiment_matched = any(word in response.lower() for word in ["understand", "however", "but"])
            else: 
                sentiment_matched = any(word in response.lower() for word in ["okay", "alright", "understand"])
                
            results.append(sentiment_matched)
        
        return {
            'accuracy': sum(results) / len(results),
            'context_awareness': sum(1 for case, _ in test_cases if case["last_intent"] and "last_intent" in context)
        }

if __name__ == "__main__":
    print("Starting Chatbot Evaluation...")
    evaluation_report = run_full_evaluation()
    print("\nEvaluation Summary:")
    print(evaluation_report)
