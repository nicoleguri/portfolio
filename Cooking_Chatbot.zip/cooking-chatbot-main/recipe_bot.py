import sqlite3
import ast
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from check_db import RecipeDatabase
from query_utils import expand_query
from fuzzywuzzy import fuzz

class RecipeSearchBot:
    """
    A class to handle recipe search operations using a TF-IDF vectorizer and cosine similarity.

    Methods:
    - __init__: Initialises the RecipeSearchBot and prepares the TF-IDF matrix.
    - search_recipe: Searches for recipes based on a user's query with a similarity threshold.
    - get_ingredients: Retrieves the ingredients for a recipe by its title.
    - get_directions: Retrieves the directions for a recipe by its title.
    - search_recipes_by_keyword: Searches for recipes by keyword with a result limit.
    - get_recipe_titles_by_keyword: Retrieves recipe titles that match a given keyword.
    - save_recipe_to_favorites: Saves a recipe to a user's favourites.
    - get_favorites: Retrieves the user's favourite recipes.
    """

    def __init__(self, db_name='recipes.db'):
        """
        Initialise the RecipeSearchBot with a database connection and prepare the TF-IDF matrix.
        
        Parameters:
        - db_name (str): The name of the SQLite database.
        """
        self.db = RecipeDatabase(db_name=db_name)
        self.tfidf_matrix, self.vectorizer = self.db.apply_tfidf_vectorizer()
            
        # Dynamic template-based responses
        self.response_templates = {
            'greeting': [
                "Hi {name}! {followup}",
                "Hello {name}! {followup}",
                "Hey there {name}! {followup}",
                "Welcome {name}! {followup}"
            ],
            'followup_phrases': [
                "Ready to cook something amazing?",
                "Looking for some culinary inspiration?",
                "What's cooking?",
                "How can I help in the kitchen today?"
            ],
            'thanks': [
                "You're {intensity} welcome! {extra}",
                "{glad} I could help! {extra}",
                "Anytime! {extra}",
                "No problem at all! {extra}"
            ],
            'intensity_words': ['very', 'so', 'really'],
            'glad_phrases': ['Glad', 'Happy', 'Delighted'],
            'extra_phrases': [
                "Happy cooking!",
                "Let me know how the recipe turns out!",
                "Enjoy your cooking adventure!",
                "Cook with passion!"
            ],
            'recipe_success': [
                "That's {intensity} {positive}! {followup}",
                "Wonderful! {followup}",
                "Amazing! {followup}",
                "Fantastic! {followup}"
            ],
            'positive_words': ['great', 'fantastic', 'awesome', 'excellent'],
            'success_followup': [
                "You're becoming quite the chef!",
                "Would love to hear more about how you made it!",
                "Keep experimenting in the kitchen!",
                "Your culinary skills are growing!"
            ]
        }


    def search_recipe(self, query):
        """
        Search for recipes using a two-stage matching process:
        1. Attempt fuzzy string matching on recipe titles
        2. Fall back to TF-IDF vectorization with cosine similarity if no direct match
        
        Parameters:
            query (str): The user's search query
            
        Returns:
            dict: Recipe details including title, ingredients, and directions
                May include "suggestions" key if similar recipes are found
            str: Error message if no matches are found
        """
        normalized_query = ''.join(c for c in query.lower().strip() if not c.isdigit())
        
        # Fuzzy matching on titles
        all_recipes = self.db.get_all_recipes_text()
        best_ratio = 0
        best_match = None
        
        for recipe in all_recipes:
            ratio = fuzz.ratio(normalized_query, recipe[1].lower())
            if ratio > best_ratio:
                best_ratio = ratio
                best_match = recipe[1]
        
        # If a good match is found, return it
        if best_ratio > 80:
            result = self.db.get_all_recipe_details_by_title(best_match)
            if result:
                title, ingredients, directions = result
                return {
                    "title": title,
                    "ingredients": ingredients,
                    "directions": directions
                }
        
        # If no good fuzzy match, continue with existing TF-IDF logic, use expanded query for fuzzy matching
        expanded_query = expand_query(query)
        query_vector = self.vectorizer.transform([expanded_query])
        cosine_similarities = cosine_similarity(query_vector, self.tfidf_matrix).flatten()

        similarity_threshold = 0.05  
        matches = [(i, score) for i, score in enumerate(cosine_similarities) if score > similarity_threshold]
        
        if not matches:
            return f"I'm sorry, I couldn't find a recipe titled '{query}'. Try another ingredient or dish name."

        # Sort matches by similarity score
        matches.sort(key=lambda x: x[1], reverse=True)
        best_matches = matches[:3] 
        
        best_index = best_matches[0][0]
        recipe_title = self.db.get_all_recipes_text()[best_index][1]
        
        result = self.db.get_all_recipe_details_by_title(recipe_title)
        if result:
            title, ingredients, directions = result
            response = {
                "title": title,
                "ingredients": ingredients,
                "directions": directions
            }
            
            # Add suggestions if there are close matches
            if len(best_matches) > 1 and (best_matches[0][1] - best_matches[1][1]) < 0.1:
                suggestions = [self.db.get_all_recipes_text()[i][1] for i, _ in best_matches[1:]]
                response["suggestions"] = suggestions
                
            return response


    def get_ingredients(self, title):
        """
        Get ingredients for a specific recipe.
        
        Parameters:
        - title (str): The title of the recipe to search for
        
        Returns:
        - dict: Recipe details including title and ingredients
        - str: Error message if recipe not found
        """
        try:
            # Normalize the title
            normalized_title = ' '.join(word.capitalize() for word in title.strip().split())
            
            # First try exact match
            result = self.db.get_recipe_by_title(normalized_title)
            
            # If no exact match, try case-insensitive search
            if not result:
                result = self.db.get_recipe_by_title(title.lower().strip())
                
            if result:
                return {
                    "title": result["title"],
                    "ingredients": result["ingredients"]
                }
            return f"I couldn't find ingredients for '{title}'. Please check the recipe name and try again."
        except Exception as e:
            return f"Sorry, I had trouble finding ingredients for '{title}'. Please try again."


    def get_directions(self, title):
        """
        Retrieve the directions for a recipe by its title.

        Parameters:
        - title (str): The title of the recipe.

        Returns:
        - dict: The recipe title and directions.
        - None: If the recipe is not found or an error occurs.
        """
        normalized_title = title.lower().strip()

        try:
            result = self.db.get_directions_by_title(normalized_title)
            if result:
                recipe_title, directions = result
                directions_list = ast.literal_eval(directions) if isinstance(directions, str) else directions
                return {
                    "title": recipe_title,
                    "directions": directions_list
                }
            return None
        except Exception as e:
            return None


    def search_recipes_by_keyword(self, keyword, limit=10):
        """
        Search recipes based on a keyword, limiting the results.
        
        Parameters:
        - keyword (str): The category or type of recipe (e.g., "cake", "soup").
        - limit (int): The maximum number of recipes to return.
        
        Returns:
        - list: A list of recipes matching the keyword.
        """
        try:
            recipes = self.db.get_recipes_by_keyword(keyword.lower().strip(), limit)
            return [{"title": recipe[1]} for recipe in recipes]
        except Exception as e:
            return []


    def get_recipe_titles_by_keyword(self, keyword):
        """
        Retrieve all recipe titles that match a keyword.

        Parameters:
        - keyword (str): The keyword to search for.

        Returns:
        - list: A list of recipe titles matching the keyword.
        """
        return self.db.get_recipes_by_keyword(keyword)


    def save_recipe_to_favorites(self, user_name, title, ingredients, directions):
        """
        Save a recipe to the user's favorites.
        """
    
        try:
            connection = self.db._connect()
            cursor = connection.cursor()

            # Insert into the favorites table or ignore it if already exists
            cursor.execute('''
                INSERT OR IGNORE INTO favorites (user_name, title, ingredients, directions)
                VALUES (?, ?, ?, ?)
            ''', (user_name, title, str(ingredients), str(directions)))
            
            if cursor.rowcount == 0: 
                return f"The recipe '{title}' is already in your favorites."

            connection.commit()
            return f"The recipe '{title}' has been saved to your favorites."
        except Exception as e:
            return f"Sorry, there was an error saving the recipe '{title}'."
        finally:
            connection.close()


    def get_favorites(self, user_name):
        """
        Retrieve the user's favourite recipes.

        Parameters:
        - user_name (str): The name of the user.

        Returns:
        - str: A formatted list of the user's favourite recipes or an error message.
        """
        try:
            favourites = self.db.get_favorite_recipes(user_name)
            if favourites:
                formatted_favourites = "\n".join(
                    [f"{i+1}. {fav[0]} - Ingredients: {fav[1]}, Directions: {fav[2]}" for i, fav in enumerate(favourites)]
                )
                return f"Here are your saved recipes:\n{formatted_favourites}"
            return "You don't have any saved recipes yet!"
        except Exception as e:
            return "An error occurred while retrieving your saved recipes."
        

    def delete_from_favorites(self, user_name, title):
        """
        Delete a recipe from the user's favorites.
        
        Parameters:
        - user_name (str): The name of the user
        - title (str): The title of the recipe to delete
        
        Returns:
        - str: A message indicating success or failure
        """
        if self.db.delete_favorite_recipe(user_name, title):
            return f"Successfully removed '{title}' from your favorites."
        return f"Could not find '{title}' in your favorites."