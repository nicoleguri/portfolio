import sqlite3
import ast
from sklearn.feature_extraction.text import TfidfVectorizer


class RecipeDatabase:
    """
    A class to manage the recipe database, including setup, data insertion, 
    retrieval, and text vectorization for search purposes.
    """

    def __init__(self, db_name='recipes.db'):
        """
        Initialize the RecipeDatabase instance and set up the database.

        Parameters:
        - db_name (str): The name of the SQLite database file.
        """
        self.db_name = db_name
        self.setup_database()


    def _connect(self):
        """
        Establish a connection to the SQLite database.

        Returns:
        - Connection object for the SQLite database.
        """
        return sqlite3.connect(self.db_name)


    def setup_table(self, create_statement):
        """
        Set up a table in the database with the given SQL CREATE TABLE statement.

        Parameters:
        - create_statement (str): The SQL statement to create the table.
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            cursor.execute(create_statement)
            connection.commit()
        finally:
            connection.close()


    def setup_database(self):
        """
        Set up the necessary tables for storing recipes and user data.
        """
        self.setup_table('''
            CREATE TABLE IF NOT EXISTS recipes_final (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                ingredients TEXT NOT NULL,
                directions TEXT NOT NULL
            )
        ''')
        self.setup_table('''
            CREATE TABLE IF NOT EXISTS user_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL UNIQUE,
                value TEXT NOT NULL
            )
        ''')
        self.setup_table('''
            CREATE TABLE IF NOT EXISTS favorites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_name TEXT NOT NULL,
                title TEXT NOT NULL,
                ingredients TEXT NOT NULL,
                directions TEXT NOT NULL,
                UNIQUE(user_name, title)
            )
        ''')


    def save_user_data(self, key, value):
        """
        Save a key-value pair to the user_data table.

        Parameters:
        - key (str): The unique key to identify the data.
        - value (str): The value to be associated with the key.
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO user_data (key, value)
                VALUES (?, ?)
            ''', (key, value))
            connection.commit()
        finally:
            connection.close()


    def get_user_data(self, key):
        """
        Retrieve the value associated with a key from the user_data table.

        Parameters:
        - key (str): The unique key to identify the data.

        Returns:
        - str or None: The associated value, or None if not found.
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            cursor.execute('SELECT value FROM user_data WHERE key = ?', (key,))
            result = cursor.fetchone()
            return result[0] if result else None
        finally:
            connection.close()


    def insert_recipe(self, title, ingredients, directions):
        """
        Insert a new recipe into the database.

        Parameters:
        - title (str): Title of the recipe.
        - ingredients (list): List of ingredients.
        - directions (list): List of directions.
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            cursor.execute('''
                INSERT INTO recipes_final (title, ingredients, directions)
                VALUES (?, ?, ?)
            ''', (title, str(ingredients), str(directions)))
            connection.commit()
        finally:
            connection.close()


    def get_directions_by_title(self, title):
        """
        Retrieve the directions for a recipe by its exact title.

        Parameters:
        - title (str): The exact title of the recipe.

        Returns:
        - tuple or None: (title, directions_list) if the recipe is found, otherwise None.
        """
        connection = self._connect()
        cursor = connection.cursor()
        cursor.execute("SELECT title, directions FROM recipes_final WHERE LOWER(title) = ?", (title.lower(),))
        result = cursor.fetchone()
        connection.close()

        if result:
            try:
                title, directions = result
                directions_list = ast.literal_eval(directions)
                return title, directions_list
            except (ValueError, SyntaxError):
                return None
        return None

    
    def get_all_recipe_details_by_title(self, title):
        """
        Retrieve the full details (title, ingredients, directions) for a recipe by its exact title.

        Parameters:
        - title (str): The exact title of the recipe.

        Returns:
        - tuple: (title, ingredients, directions) if the recipe is found.
        - None: If no recipe matches the title.
        """
        connection = self._connect()
        cursor = connection.cursor()
        query = "SELECT title, ingredients, directions FROM recipes_final WHERE LOWER(title) = ?"
        cursor.execute(query, (title.lower(),))
        result = cursor.fetchone()
        connection.close()

        if result:
            try:
                title, ingredients, directions = result
                ingredients_list = ast.literal_eval(ingredients)
                directions_list = ast.literal_eval(directions)
                return title, ingredients_list, directions_list
            except (ValueError, SyntaxError):
                return None
        return None


    def get_all_recipes_text(self):
        """
        Retrieve all recipes as text data for vectorization or search purposes.

        Returns:
        - list of tuples: A list of recipes in the format (id, title, ingredients, directions).
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            cursor.execute("SELECT id, title, ingredients, directions FROM recipes_final")
            recipes = cursor.fetchall()
            valid_recipes = []
            for recipe in recipes:
                recipe_id, title, ingredients, directions = recipe
                if not title or not ingredients or not directions:
                    continue

                try:
                    ingredients_list = ast.literal_eval(ingredients) if ingredients.strip() else []
                    directions_list = ast.literal_eval(directions) if directions.strip() else []

                    if isinstance(ingredients_list, list) and isinstance(directions_list, list):
                        valid_recipes.append((recipe_id, title, ingredients_list, directions_list))
                except (ValueError, SyntaxError):
                    continue

            return valid_recipes
        except sqlite3.Error:
            return []
        finally:
            connection.close()


    def get_ingredients_by_title(self, title):
        """
        Retrieve the ingredients for a recipe by its exact title.

        Parameters:
        - title (str): The exact title of the recipe.

        Returns:
        - tuple: (title, ingredients) if the recipe is found.
        - None: If no recipe matches the title.
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            query = "SELECT title, ingredients FROM recipes_final WHERE LOWER(title) = ?"
            cursor.execute(query, (title.lower(),))
            result = cursor.fetchone()
            if result:
                recipe_title, ingredients = result
                ingredients_list = ast.literal_eval(ingredients)
                return recipe_title, ingredients_list
        except (sqlite3.Error, ValueError, SyntaxError):
            pass
        finally:
            connection.close()
        return None


    def get_recipes_by_keyword(self, keyword, limit=10):
        """
        Retrieve a random selection of recipes that match a given keyword, with a limit on results.
        
        Parameters:
        - keyword (str): The keyword to search in recipe titles or ingredients.
        - limit (int): The maximum number of recipes to return.
        
        Returns:
        - list: A list of randomly selected recipes matching the keyword.
        """
        connection = self._connect()
        cursor = connection.cursor()

        query = """
        SELECT id, title, ingredients, directions
        FROM recipes_final
        WHERE LOWER(title) LIKE ? OR LOWER(ingredients) LIKE ?
        ORDER BY RANDOM()
        LIMIT ?
        """
        cursor.execute(query, (f"%{keyword}%", f"%{keyword}%", limit))

        recipes = cursor.fetchall()
        connection.close()
        return recipes
    
    
    def save_favorite_recipe(self, user_name, title, ingredients, directions):
        try:
            connection = self._connect()
            cursor = connection.cursor()
            cursor.execute('''
                INSERT INTO favorites (user_name, title, ingredients, directions)
                VALUES (?, ?, ?, ?)
            ''', (user_name, title, str(ingredients), str(directions)))
            connection.commit()
            return f"The recipe '{title}' has been saved to your favorites."
        except sqlite3.Error as e:
            return f"Sorry, there was an error saving the recipe '{title}'."
        finally:
            connection.close()


    def get_favorite_recipes(self, user_name):
        """
        Retrieve all favorite recipes for the user.
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            cursor.execute('''
                SELECT title, ingredients, directions 
                FROM favorites 
                WHERE LOWER(user_name) = LOWER(?)
            ''', (user_name,))
            favorites = cursor.fetchall()
            
            # Parse the string representations back into lists
            parsed_favorites = []
            for title, ingredients_str, directions_str in favorites:
                try:
                    ingredients = ast.literal_eval(ingredients_str)
                    directions = ast.literal_eval(directions_str)
                    parsed_favorites.append((title, ingredients, directions))
                except (ValueError, SyntaxError):
                    continue
                
            return parsed_favorites
        except sqlite3.Error as e:
            return []
        finally:
            connection.close()


    def delete_favorite_recipe(self, user_name, title):
        """
        Delete a recipe from user's favorites.
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            cursor.execute('''
                DELETE FROM favorites 
                WHERE user_name = ? AND LOWER(title) = LOWER(?)
            ''', (user_name, title))
            connection.commit()
            return cursor.rowcount > 0
        finally:
            connection.close()


    def get_recipe_by_title(self, title):
        """
        Get a specific recipe by its title.
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            
            # Try exact match first
            cursor.execute("""
                SELECT title, ingredients, directions 
                FROM recipes_final 
                WHERE LOWER(title) = LOWER(?)
                OR LOWER(title) LIKE LOWER(?)
            """, (title, f"%{title}%"))
            
            result = cursor.fetchone()
            if result:
                title, ingredients_str, directions_str = result
                return {
                    'title': title,
                    'ingredients': ast.literal_eval(ingredients_str),
                    'directions': ast.literal_eval(directions_str)
                }
            return None
        except (sqlite3.Error, ValueError, SyntaxError) as e:
            return None
        finally:
            connection.close()


    def apply_tfidf_vectorizer(self):
    
        """
        Generate a TF-IDF matrix for the recipe data to support text-based search.
        
        Returns:
        - tfidf_matrix (sparse matrix): TF-IDF matrix representing recipe content.
        - vectorizer (TfidfVectorizer): The fitted TF-IDF vectorizer.
        """
        recipes = self.get_all_recipes_text()
        recipes_text = []

        for recipe in recipes:
            title = recipe[1].lower()
            ingredients = recipe[2]
            directions = recipe[3]

            # Combine title, ingredients, and directions into a single string for vectorisation
            recipe_text = " ".join([title, " ".join(ingredients).lower(), " ".join(directions).lower()]).strip()
            if recipe_text:
                recipes_text.append(recipe_text)

        if not recipes_text:
            raise ValueError("No valid recipes found for vectorization.")

        vectorizer = TfidfVectorizer(stop_words="english")
        tfidf_matrix = vectorizer.fit_transform(recipes_text)
        return tfidf_matrix, vectorizer


    def clear_user_tables(self):
        """
        Clear all data from the user_data and favorites tables.
        
        Returns:
        - tuple: (number of rows deleted from user_data, number of rows deleted from favorites)
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            
            # Delete all rows from user_data
            cursor.execute('DELETE FROM user_data')
            user_data_rows = cursor.rowcount
            
            # Delete all rows from favorites
            cursor.execute('DELETE FROM favorites')
            favorites_rows = cursor.rowcount
            
            connection.commit()
            return (user_data_rows, favorites_rows)
        finally:
            connection.close()


    def analyze_recipes_table(self):
        """
        Analyze the recipes_final table contents and size.
        
        Returns:
        - dict: Statistics about the table including row count, average sizes, etc.
        """
        try:
            connection = self._connect()
            cursor = connection.cursor()
            
            # Get total row count
            cursor.execute("SELECT COUNT(*) FROM recipes_final")
            total_rows = cursor.fetchone()[0]
            
            # Get sample of largest entries by total content size
            cursor.execute("""
                SELECT 
                    id,
                    title,
                    length(ingredients) as ing_size,
                    length(directions) as dir_size,
                    length(ingredients) + length(directions) as total_size
                FROM recipes_final
                ORDER BY total_size DESC
                LIMIT 5
            """)
            largest_entries = cursor.fetchall()
            
            # Get average sizes
            cursor.execute("""
                SELECT 
                    AVG(length(ingredients)) as avg_ing_size,
                    AVG(length(directions)) as avg_dir_size
                FROM recipes_final
            """)
            avg_sizes = cursor.fetchone()
            
            return {
                "total_rows": total_rows,
                "largest_entries": largest_entries,
                "avg_ingredient_size": round(avg_sizes[0], 2),
                "avg_directions_size": round(avg_sizes[1], 2)
            }
        finally:
            connection.close()


    