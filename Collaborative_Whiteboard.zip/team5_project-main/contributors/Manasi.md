# Manasi's contribution to project
<ul>
    <li>set up the initial meeting to gather everyone, became team lead</li>
    <li>set up and made the channels for discord so we can keep organised </li>
    <li>conducted and participated in the small peer CV review </li>
    <li>set up the weekly plans and weekly reviews markdown </li>
    <li>set up the contributors markdowns so we can keep track of what everyone has done </li>
    <li>Wrote out all the deadline dates so we can keep track of when everything in due</li>
    <li>Set up all the Canva boards so everyone can collaborate on the presentations together</li>
        <li>[Presentation for UoN](https://www.canva.com/design/DAFw8dt6XZE/ZYWmqfoaWIP2D2H6gmM7vg/edit)</li>
        <li>[Presentation for BJSS](https://www.canva.com/design/DAFw8SfLOJY/kbU5_18emX9hvSQeH0yLoA/edit)</li>
        <li>[Presentation for IBM](https://www.canva.com/design/DAFw8a234V4/VjUWfhTvtuBmH8UG8hgp_w/edit)</li>
    <li>Split the group into different presentation groups so they can work collaboratively on every project</li>
    <li>Worked on the group skills and technologies needed for each project on the presentation</li>
    <li>Introduced the projects on all the presentations and spoke about the the USP for the pet project</li>
    <li>Set up the kanban boards with what everyone needed to fulfil for the first deadline</li>
    <li>Set up a questions and answer channel on the discord to come up with questions in the Q&A sessions</li>
    <li>Wrote all 3 EOIs for the projects we were pitching for</li>
    <li>Planned out the weekly stand-up/meetings with Jason for the project</li>
    <li>Made a requirements channel to ensure all Q&As are answered in our first meeting with Jason and we have explicit requirements</li>
    <li>Assigned different roles for every member in the team</li>
        <li>Manasi - backend </li>
        <li>Ian - backend</li>
        <li>Nicole - frontend</li>
        <li>Sam - backend</li>
        <li>Amal - frontend</li>
        <li>Varsh - backend</li>
        <li>Jackson - frontend</li>
        <li>Megan - frontend</li>
    <li>Set up Sprint 1 planning:</li>
    <li>Established we need the following UMLs: uml: personas, activity, sequence, user stories, use case </li>
        <li>persona - nicole + megan - 1</li>
        <li>activity - amal + manasi - 2</li>
        <li>sequence - sam + jackson -2 </li>
        <li>user stories - ian + varsh - 1</li>
        <li>use case - ian + varsh - 1</li>
    <li>Introduced story points which need to be documented for full transparency of work</li>
    <li>Set up sprint 1 and interim report milestones</li>
    <li>Set up documentation for interim report</li>
    <li>Set up research channels for front-end and back-end research</li>
    <li>Led the meeting with Jason so everyone is on the same page for requirements</li>
    <li>Set up developer stand-ups with the team and established our sprints will work Monday to Monday</li>
    <li>Created the Gantt chart for semester 1</li>
    <li>Wrote the beginning part of the documentation</li>
    <li>Planned the sprints out with the team</li>
    <li>Collected the story points for sprint 1 </li>
    <li>Made the agile template for each Sprint for team lead</li>
    <li>Wrote all the interim report</li>
    <li>Wrote all the software specification report</li>
    <li>Helped set up Gitlab</li>
    <li>Sent out the user survey</li>
    <li>Set up superbase for the backend</li>
    <li>Did the implementation of the sql login version</li>
    <li>Done redo-undo for text</li>
    <li>Write the final report</li>
    <li>Done the gantt chart for semester 2</li>
    <li>Writing unit tests for api and database</li>
    <li>Set up the user+session database on superbase</li>
    <li>Did undo redo functionality on all objects<li>
    <li>Added delete function on all objects</li>
    <li>frontend and backend incorportated</li>
    <li>broadcasted the pens and text boxes<li>
    <li>wrote and gave the presentation for the showcase</li>
    <li>did the poster for the showcase</li>
    <li>fixed object spawning on the page<li>
    <li>merged branches and helped git admin</li>
</ul>