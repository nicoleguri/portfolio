# Nicole's contribution to project

- Meeting 1(week 1): Had a virtual meeting with the team and I was elected as the Team Admin.

- Meeting 2(week 2): I expressed my interest on the Smart Onboarding and Food AI projects, projects which the memebres of the team also liked.

- On the 3rd, 4th and 5th of October, as the Team Admin, I submitted the projects that our team sellected, which were: Food AI, Browser-based Collaborative Environment and Watson Assisted Living Pet. All three projects were liked and accepted by the team members.

- Meeting 3(week 3): Had discussions with the team and wrote a presantation about myself and how my skills are best adapted to the projects we picked.

- 16th of October we filmed the pitch videos. My role was to talk about the prototype on the Food AI project and for the market research on the Watson Assisted Living pet project. We filmed all the pitch videos that day with success.
- On the 18th of October, as Team Admin, I submitted the three EOIs, Pitch Videos and CVs.

- After receiving the decision that wee were selected for the Collaborative Space Environment, we started our group sprints. I worked with Megan to create the Personas for this project.

- At the end of the term, I submitted the peer review and the report for the first part of the project.

- For this project I joined the front end team.

- As of the project now, I have done the menu bar, the buttons of the undo,redo and save, and the pen functionality for the whiteboard.

- I have attened the weekly meetings with the team and with Jason.

- Wrote meeting minutes weekly and put them into gitlab.

- Designed the shaded area for the private hands.
 
- Fixed card positioning, so they would fall ito the sh- aded area.

-  Wrote Personal Report and completed the peer reviews.

- Submitted all final documents on 3rd and 15th of May.
