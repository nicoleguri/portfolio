# Megan's contribution to project

- Researched all project briefs prior to first meeting, during first meeting expressed interest in the Watson Assisted Living Pet project by IBM because of previous work experience.  
- Initially took meeting minutes, created markdown template for minutes going forward and agreed to take minutes if the team admin is unable to do so.
- After selecting 3 proojects we wanted to pitch, was assigned to the Watson Assisted Living Pet project team.  
- Completed [CV](/CVs/MeganFarfarakis-CV.pdf) and wrote up personal EoI to be collated with other member's.
- Started work on Watson Assisted Living Pet pitch presentation.
    - Conducted market research on similar applications and create slide for presentation.  
    - Created mock up prototypes for presentation.  
    - <img src="../docs/Misc/MegProtoype.png" width="250" height="150">  
    - Aided with coordinating font and colour scheme across finished presentation.
- Opted to speak in all 3 pitch videos - protoypes for IBM, market research for BJSS and UoN - personal additional market research conducted for the BJSS and UoN to ensure projects were understood well.
- Recieved group project allocation and got Browser Based Collaborative Environment – UoN. Opted to be on the frontend team.
- Started week 1 sprints and worked collaboratively with Nicole to create [personas](/UML/Personas/Personas.md).
