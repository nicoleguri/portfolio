# Ian's contribution to project


Meeting 1: We organised a virtual teams meeting and I was elected as the Git Admin.

Oct 2. Created git mark down and dev branch such that projects going on would not break the current branch. 

Meeting 2: We expressed our interest for different project and agreed on Food AI project, Watson pet and Spotify Music album. 

Meeting 3: Had discussions with for the upcoming weekend. Agreed on working on CV. Our team were split into 3 to work on the presentation. Everyone agreed that if I don’t want to be in the video, they were fine with it.   

Meeting 4: Created a Kanban board on Git. +Completed CV during the weekend. 

Meeting 5: Quick meetup on the Oct. 9 th going through our CVs. 


======


Week 4 Meetings: Submitted CVs + Waiting for project to be announced 

Week 5 Meetings: Got the UON collaborative workspace project and being planning the sprints. 

Week 6 Meetings: (Nov 3rd) Met up with suppervisor to draft + understand what is expeted. I prepared questions and clarified them with Jason

Week 7 Meetings (8?): (Nov 6th) Within the group we assigned parts for sprint 1, I did user stories. There was a bit of misclarification as I did the user stories before req. were completed. 

Week 8 Meeting (9) : (Nov 13th) Meet for sprint 2, took the role of user survey. Would beed to create a forms and get people to answer it. 

During the break not much was done for the project
I had to refresh myself on how react and our database work. 
Learn the database api calls.  

Jan. 30th
Coming back from the break I merged dev to main preping the team for the first version tag.  

Feb. 16th
Worked on login funtionality.  
Improve the funtionallity that allows for uploading of images. 
Merged backend to main and get the website ready for basic testing. 

Feb. 20th 
Added the base funtionallity to view roomcode on the whiteboard. 
Added a popup test to check if the roomcode entered is empty/ does it have 8 int digit. 

Started to implement textboxes. 


March. 
Merged pen funtionallities to dev. 

End of March. 
Added functionality to change usernames within the session. 
Finish textbox implementation. 

Mid. April
Added unit test for API for Version 2. 
Continue to merge various branch to dev. 


